<footer class="footer">
   BLOG.AJUM
</footer>